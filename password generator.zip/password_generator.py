import string
import random

print("Welcome to the Password Generator!")

try:
    length = int(input("How many characters do you want in your password? "))
except ValueError:
    print("Please enter a valid number.")
    exit()

characters = ""

if input("Include digits? (y/n): ").lower() == "y":
    characters += string.digits

if input("Include lowercase letters? (y/n): ").lower() == "y":
    characters += string.ascii_lowercase

if input("Include uppercase letters? (y/n): ").lower() == "y":
    characters += string.ascii_uppercase

if input("Include symbols? (y/n): ").lower() == "y":
    characters += string.punctuation

if not characters:
    print("You must select at least one character type.")
    exit()

password = ''.join(random.choice(characters) for _ in range(length))
if not characters:
    print("You must select at least one character type.")
    sys.exit()

